The book covers in this project are created with CSS gradients, so no external image downloads are needed.
